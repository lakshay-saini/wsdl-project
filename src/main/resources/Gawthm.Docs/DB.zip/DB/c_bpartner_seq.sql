﻿-- Sequence: workflow.c_bpartner_seq

-- DROP SEQUENCE workflow.c_bpartner_seq;

CREATE SEQUENCE workflow.c_bpartner_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE workflow.c_bpartner_seq
  OWNER TO administrator;
